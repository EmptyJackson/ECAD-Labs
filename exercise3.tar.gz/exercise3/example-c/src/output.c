# include "output.h"

void hex_output(int value)
{
	int *hex_leds = (int *) 0x04000080;  // define a pointer to the register
	*hex_leds = value;                   // write the value to that address
}

void debug_print(int value)
{
	asm ("csrw	0x7B2, %0" : : "r" (value) );
}