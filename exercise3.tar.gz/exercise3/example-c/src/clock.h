# ifndef CLOCK_H
# define CLOCK_H

int digi_clock();

# endif