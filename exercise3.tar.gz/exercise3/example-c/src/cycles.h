# ifndef CYCLES_H
# define CYCLES_H

int get_time();

# endif