# ifndef DIVFUNCTS_H
# define DIVFUNCTS_H

int div(int a, int b);
int rem(int a, int b);

# endif