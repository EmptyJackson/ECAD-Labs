#include "clock.h"
#include "output.h"

int main(void)
{
	while (1) {
	        int time= digi_clock();
	        hex_output(time);
	}

	return 0;
}
