# include "clock.h"
# include "divfuncts.h"
# include "cycles.h"

const int TICKS_PER_CENTISECOND= 10;

int digi_clock() {
	int time = get_time();
	time = div(time, TICKS_PER_CENTISECOND);
	
	int centiseconds =  rem(time, 100);
	time = div(time, 100);

	int seconds = rem(time, 60);
	time = div(time, 60);

	int minutes = rem(time, 100);

	int ret = 0;
	ret += rem(centiseconds, 10);
	ret += div(centiseconds, 10) << 4;
	ret += rem(seconds, 10) << 8;
	ret += div(seconds, 10) << 12;
	ret += rem(minutes, 10) << 16;
	ret += div(minutes, 10) << 20;

	return ret;
}