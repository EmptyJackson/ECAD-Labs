# ifndef AVALON_IO_H
# define AVALON_IO_H

int avalon_read(unsigned int address);
void avalon_write(unsigned int address, int data);
int button_pressed(int button_mask);

# endif