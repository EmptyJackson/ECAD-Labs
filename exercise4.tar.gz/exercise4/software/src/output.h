# ifndef OUTPUT_H
# define OUTPUT_H

void hex_output(int value);
void debug_print(int value);

# endif