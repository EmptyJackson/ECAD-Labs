#include "avalon_addr.h"
#include "avalon_io.h"
#include "draw.h"

int limit (int value, int min, int max) {
	if (value < min) {
		return min;
	} else if (value > max) {
		return max;
	} else {
		return value;
	}
}

int main(void)
{
	int x = 0;
	int y = 0;

	int rot_x = avalon_read(PIO_ROTARY_L);
	int rot_y = avalon_read(PIO_ROTARY_R);

	while (1) {
		int next_rot_x = avalon_read(PIO_ROTARY_L);
		int next_rot_y = avalon_read(PIO_ROTARY_R);
		
		int dx = next_rot_x - rot_x;
		int dy = next_rot_y - rot_y;
		
		// Assuming wraparound for rotary changes greater than 50
		if (dx > 50)
			x += 256 - dx;
		else if (dx < -50)
			x -= 256 + dx;
		else
			x += dx;

		if (dy > 50)
			y += 256 - dy;
		else if (dy < -50)
			y -= 256 + dy;
		else
			y += dy;
		
		x = limit(x, 0, DISPLAY_WIDTH - 1);
		y = limit(y, 0, DISPLAY_HEIGHT - 1);

		rot_x = next_rot_x;
		rot_y = next_rot_y;

		if (button_pressed(BUTTONS_MASK_DIALR_CLICK)
		  || button_pressed(BUTTONS_MASK_DIALL_CLICK)) {
			clear_screen();
		}

		vid_set_pixel(x, y, PIXEL_WHITE);
	}
}
